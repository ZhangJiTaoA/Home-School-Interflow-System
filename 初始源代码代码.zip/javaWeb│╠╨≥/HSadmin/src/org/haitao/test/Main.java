package org.haitao.test;

import org.haitao.service.impl.StudentService;
import org.haitao.service.impl.TeacherService;

public class Main {
	public static void main(String args[]) {
		
	}
}
